package com.example.appmenu.pantallas

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable

@Composable
fun Pantalla5() {
    Text("Estás en la pantalla 5")
}
